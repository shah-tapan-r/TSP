#!/bin/bash
../SCRIPTS/aggregator.sh COLLAB-OUT/ COLLAB-IN/seed.txt
