#! /bin/bash

while true; do
../SCRIPTS/collect.sh $1 $2
sleep 100
done
